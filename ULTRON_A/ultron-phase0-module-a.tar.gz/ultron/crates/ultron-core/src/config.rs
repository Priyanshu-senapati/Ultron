//! Configuration loading and on-disk layout.
//!
//! Default location: `%APPDATA%\ULTRON\config.toml`
//! Data dir:         `%APPDATA%\ULTRON\data\`
//! Logs dir:         `%APPDATA%\ULTRON\logs\`
//!
//! On first run, a config with sane defaults and a freshly generated bridge
//! token is written. Edit it to taste; restarts pick up the new values.

use crate::error::{CoreError, CoreResult};
use serde::{Deserialize, Serialize};
use std::path::{Path, PathBuf};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Config {
    pub general: GeneralConfig,
    pub bridge: BridgeConfig,
    pub tension: TensionConfig,
    pub input: InputConfig,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GeneralConfig {
    pub user_name: String,
    pub data_dir: PathBuf,
    pub logs_dir: PathBuf,
    pub heartbeat_secs: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BridgeConfig {
    pub bind: String,    // "127.0.0.1:9420"
    pub token: String,   // shared secret for ws clients
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TensionConfig {
    pub ewma_alpha: f32,         // 0.0 .. 1.0 — higher = reacts faster
    pub decay_per_sec: f32,      // 0.0 .. 1.0 — natural decline of tension
    pub w_typing_volatility: f32,
    pub w_click_rate: f32,
    pub w_error_signal: f32,
    pub w_idle: f32,             // negative-pressure: idle drops tension
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct InputConfig {
    pub enable_keyboard_hook: bool,
    pub enable_mouse_hook: bool,
    pub mouse_move_min_interval_ms: u64,
    pub idle_threshold_secs: u32,
}

impl Default for Config {
    fn default() -> Self {
        let base = ultron_data_root();
        Self {
            general: GeneralConfig {
                user_name: "Priyanshu".into(),
                data_dir: base.join("data"),
                logs_dir: base.join("logs"),
                heartbeat_secs: 5,
            },
            bridge: BridgeConfig {
                bind: "127.0.0.1:9420".into(),
                token: random_token(48),
            },
            tension: TensionConfig {
                ewma_alpha: 0.18,
                decay_per_sec: 0.015,
                w_typing_volatility: 0.35,
                w_click_rate: 0.20,
                w_error_signal: 0.40,
                w_idle: 0.10,
            },
            input: InputConfig {
                enable_keyboard_hook: true,
                enable_mouse_hook: true,
                mouse_move_min_interval_ms: 50,
                idle_threshold_secs: 90,
            },
        }
    }
}

impl Config {
    /// Load (or create-on-first-run) the config. Always returns absolute paths.
    pub fn load_or_create() -> CoreResult<Self> {
        let path = config_path();
        if !path.exists() {
            std::fs::create_dir_all(path.parent().unwrap())?;
            let cfg = Config::default();
            std::fs::create_dir_all(&cfg.general.data_dir)?;
            std::fs::create_dir_all(&cfg.general.logs_dir)?;
            let s = toml::to_string_pretty(&cfg)?;
            std::fs::write(&path, s)?;
            return Ok(cfg);
        }
        let s = std::fs::read_to_string(&path)?;
        let cfg: Config = toml::from_str(&s)?;
        std::fs::create_dir_all(&cfg.general.data_dir)?;
        std::fs::create_dir_all(&cfg.general.logs_dir)?;
        cfg.validate()?;
        Ok(cfg)
    }

    pub fn quantum_log_path(&self) -> PathBuf {
        self.general.data_dir.join("quantum.db")
    }

    fn validate(&self) -> CoreResult<()> {
        if self.bridge.token.len() < 16 {
            return Err(CoreError::Config(
                "bridge.token must be at least 16 chars".into(),
            ));
        }
        if !(0.0..=1.0).contains(&self.tension.ewma_alpha) {
            return Err(CoreError::Config("tension.ewma_alpha out of range".into()));
        }
        Ok(())
    }
}

pub fn ultron_data_root() -> PathBuf {
    if let Some(d) = dirs::data_dir() {
        d.join("ULTRON")
    } else {
        PathBuf::from(".ultron")
    }
}

pub fn config_path() -> PathBuf {
    ultron_data_root().join("config.toml")
}

/// Cryptographically-decent token. We don't need full CSPRNG vibes here —
/// the bridge port is `127.0.0.1` only — but more entropy is free.
fn random_token(len: usize) -> String {
    use std::time::{SystemTime, UNIX_EPOCH};
    const ALPHABET: &[u8] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    let mut out = String::with_capacity(len);
    let mut state = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_nanos() as u64)
        .unwrap_or(0xDEAD_BEEF);
    state ^= std::process::id() as u64;
    for _ in 0..len {
        // splitmix64
        state = state.wrapping_add(0x9E37_79B9_7F4A_7C15);
        let mut z = state;
        z = (z ^ (z >> 30)).wrapping_mul(0xBF58_476D_1CE4_E5B9);
        z = (z ^ (z >> 27)).wrapping_mul(0x94D0_49BB_1331_11EB);
        z ^= z >> 31;
        let idx = (z % ALPHABET.len() as u64) as usize;
        out.push(ALPHABET[idx] as char);
    }
    out
}

#[allow(dead_code)]
fn _path_must_be_absolute(p: &Path) -> bool {
    p.is_absolute()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn token_unique_and_long() {
        let a = random_token(48);
        let b = random_token(48);
        assert_eq!(a.len(), 48);
        assert_eq!(b.len(), 48);
        assert_ne!(a, b);
    }

    #[test]
    fn default_config_validates() {
        let c = Config::default();
        assert!(c.validate().is_ok());
    }
}
