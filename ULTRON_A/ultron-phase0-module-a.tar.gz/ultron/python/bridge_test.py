"""
ULTRON v5.1 — minimal Python WebSocket bridge test client.

Reads the bridge token from %APPDATA%/ULTRON/config.toml (or asks `ultron-core
--print-token`), connects to the core, says hello, subscribes to everything,
and prints every event.

Run:
    python -m pip install websockets tomli
    python python/bridge_test.py
"""

from __future__ import annotations

import asyncio
import json
import os
import sys
from pathlib import Path

try:
    import websockets
except ImportError:
    print("Need: pip install websockets", file=sys.stderr)
    sys.exit(2)

try:
    import tomllib  # 3.11+
except ImportError:
    try:
        import tomli as tomllib  # type: ignore
    except ImportError:
        print("Need: pip install tomli  (or use Python 3.11+)", file=sys.stderr)
        sys.exit(2)


def config_path() -> Path:
    appdata = os.environ.get("APPDATA")
    if appdata:
        return Path(appdata) / "ULTRON" / "config.toml"
    # XDG-ish fallback.
    return Path.home() / ".local" / "share" / "ULTRON" / "config.toml"


def load_bridge() -> tuple[str, str]:
    p = config_path()
    if not p.exists():
        sys.exit(f"config not found at {p}\nRun ultron-core once to bootstrap.")
    cfg = tomllib.loads(p.read_text(encoding="utf-8"))
    bind = cfg["bridge"]["bind"]
    token = cfg["bridge"]["token"]
    return bind, token


async def main() -> None:
    bind, token = load_bridge()
    url = f"ws://{bind}/ws"
    print(f"connecting to {url} ...")
    async with websockets.connect(url, ping_interval=20, ping_timeout=20) as ws:
        await ws.send(json.dumps({"op": "hello", "token": token, "role": "python-bridge"}))
        welcome = json.loads(await ws.recv())
        print("welcome:", welcome)
        if welcome.get("op") != "welcome":
            sys.exit(f"auth failed: {welcome}")

        # Subscribe to everything (empty kinds).
        await ws.send(json.dumps({"op": "subscribe", "kinds": []}))

        print("listening for events. Ctrl-C to quit.\n" + "-" * 60)
        async for raw in ws:
            try:
                msg = json.loads(raw)
            except json.JSONDecodeError:
                print("non-json:", raw)
                continue
            kind = msg.get("kind") or msg.get("op")
            payload = msg.get("payload", msg)
            print(f"[{msg.get('ts','')}] {kind}: {payload}")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nbye.")
